export class Todo{

   sno : number
   title : string
   description: string 
   active: boolean

}